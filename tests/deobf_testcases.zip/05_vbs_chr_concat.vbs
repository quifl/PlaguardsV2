' DEOBFUSCATION TEST CASE .vbs (1/2) - classic Chr() concatenation.
' Builds a benign string and ECHOES it. No Execute, no CreateObject, no I/O.
Dim s
s = Chr(91) & Chr(73) & Chr(78) & Chr(69) & Chr(82) & Chr(84) & Chr(93) & Chr(32)   ' "[INERT] "
s = s & "deobfuscation " & Chr(118) & Chr(98) & Chr(115) & " test"                   ' + "vbs"
s = s & " | C2=" & "malicious" & Chr(46) & "example" & Chr(46) & "invalid"
s = s & " | IP=198.51.100.42"
WScript.Echo s
