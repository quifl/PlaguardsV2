' DEOBFUSCATION TEST CASE .vbs (2/2) - StrReverse + Chr code building.
' Reveals the deobfuscated string via Echo. Nothing is executed.
Dim rev, part, out
rev = "dilavni.elpmaxe.suoicilam"                 ' reversed domain
part = StrReverse(rev)                              ' -> malicious.example.invalid
' build "[INERT vbs]" from codes
out = Chr(91) & "INERT " & Chr(118)&Chr(98)&Chr(115) & Chr(93)
WScript.Echo out & " StrReverse test | C2=" & part & " | IP=198.51.100.42"
