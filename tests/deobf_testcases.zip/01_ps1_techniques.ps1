# TEST CASE .ps1 (1/2) - 12 obfuscation techniques, all decoded and PRINTED. Inert.
$name="World"; $p="ab"
$dA=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String("VGVzdA=="))      # '=='  -> Test
$dB=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String("YWJj"))          # func  -> abc
$v="first"; $v="second"; $v=$v+"-third"
$cm="$([char](72+0))$([char](210/2))$([char](36*2))$([char](97 -bxor 8))"          # H i H i
W`r`i`te-H`o`st ("1:{0} | 2:{1} | 3:{2}/{3} | 6:{4} | 7:{5} | 8:{6} | 9:{7} | 10:{8} | 11:{9} | 12:{10}" -f `
  ("Hello, "+$name+"!"), ($p+$p+$p), $dA, $dB, $v, $cm, `
  ("HeXXo World" -replace "X","l"), (("a,b,c" -split ",") -join "_"), `
  (@("Ob","fus","cated") -join ""), (("val"+"   ue").Trim()), `
  ([Text.Encoding]::ASCII.GetString([byte[]](72,101,108,108,111))))
