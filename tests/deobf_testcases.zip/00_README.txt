DEOBFUSCATION TOOL TEST CORPUS  (14 files = 2 per extension x 7 extensions)
==========================================================================
Every file is BENIGN and INERT. Scripts REVEAL their content (echo/print) or,
for .txt/.log, hold it as DATA. Nothing downloads, executes decoded content,
writes persistence, makes network calls, or evades anything. All IOCs are on
reserved / non-routable ranges: *.invalid (RFC 2606) and 198.51.100.0/24
(RFC 5737 documentation range).

Common expected cleartext (the "banner"):
  [INERT DEMO] deobfuscation test | C2=malicious.example.invalid | IP=198.51.100.42:4444 | UA=EVILBOT/1.0

FILE                              TECHNIQUE UNDER TEST
--------------------------------  ------------------------------------------
01_ps1_techniques.ps1             12 string/encoding techniques -> print
02_ps1_layered.ps1                multi-stage peel (b64/reverse/b64/codes)
03_txt_encoded_blobs.txt          base64 + decimal char-code blobs (data)
04_txt_encoded_command.txt        PowerShell -enc (UTF-16LE b64) string (data)
05_vbs_chr_concat.vbs             VBScript Chr() concatenation -> Echo
06_vbs_strreverse.vbs             VBScript StrReverse + Chr -> Echo
07_js_fromcharcode.js             JScript String.fromCharCode -> Echo
08_js_reverse_split.js            JScript reverse + split/join/replace -> Echo
09_bat_set_concat.bat             batch SET concat + caret escapes -> echo
10_bat_substring.bat              batch %var:~offset,len% carving -> echo
11_cmd_delayed_expansion.cmd      cmd delayed expansion + FOR assembly -> echo
12_cmd_for_tokens.cmd             cmd FOR /F token rejoin of split -> echo
13_log_sysmon_encoded.log         encoded PS command embedded in log (extract)
14_log_proxy_iocs.log             IOCs + inline base64 in proxy log (extract)

Note: 04 and 13 contain a "powershell -enc <base64>" string. That base64 is
UTF-16LE and decodes ONLY to a Write-Host of the banner above - harmless even
if run. It is present as an extraction/decoding target, not as a live command.
