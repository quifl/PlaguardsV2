@echo off
REM DEOBFUSCATION TEST CASE .bat (2/2) - %var:~offset,length% substring carving.
REM Carves a benign string out of a larger pool and ECHOES it. No execution.
set pool=ZZmaliciousZZexampleZZinvalidZZ198.51.100.42ZZ
REM extract "malicious" (offset 2, len 9)
set dom1=%pool:~2,9%
REM extract "example" (offset 13, len 7)
set dom2=%pool:~13,7%
REM extract "invalid" (offset 22, len 7)
set dom3=%pool:~22,7%
REM extract the IP (offset 31, len 13)
set ip=%pool:~31,13%
echo [INERT] bat substring test ^| C2=%dom1%.%dom2%.%dom3% ^| IP=%ip%
