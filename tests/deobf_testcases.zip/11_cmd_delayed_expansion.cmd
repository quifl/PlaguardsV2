@echo off
REM DEOBFUSCATION TEST CASE .cmd (1/2) - delayed expansion + FOR assembly.
REM Builds a benign banner char-group by char-group and ECHOES it. No execution.
setlocal enabledelayedexpansion
set out=
for %%P in ([INERT] cmd delayed-expansion test ^| C2^=malicious.example.invalid) do (
  set out=!out! %%P
)
echo !out! ^| IP=198.51.100.42:4444
endlocal
