@echo off
REM DEOBFUSCATION TEST CASE .bat (1/2) - SET concatenation + caret escapes.
REM Assembles a benign banner and ECHOES it. No download, no invocation.
set a=[INERT]
set b= bat set-concat test
set c= ^| C2^=malicious.example.invalid
set d= ^| IP^=198.51.100.42:4444
set msg=%a%%b%%c%%d%
echo %msg%
