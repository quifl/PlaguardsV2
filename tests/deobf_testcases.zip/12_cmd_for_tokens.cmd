@echo off
REM DEOBFUSCATION TEST CASE .cmd (2/2) - FOR /F token rejoin of a split string.
REM Rejoins a delimiter-split benign domain and ECHOES it. No execution.
setlocal enabledelayedexpansion
set split=malicious#example#invalid
set dom=
for %%T in ("%split:#=" "%") do (
  set piece=%%~T
  if "!dom!"=="" ( set dom=!piece! ) else ( set dom=!dom!.!piece! )
)
echo [INERT] cmd for-token test ^| C2=!dom! ^| IP=198.51.100.42:4444 ^| UA=EVILBOT/1.0
endlocal
