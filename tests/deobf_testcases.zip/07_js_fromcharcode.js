// DEOBFUSCATION TEST CASE .js / JScript (1/2) - String.fromCharCode.
// Assembles a benign banner and ECHOES it. No eval, no ActiveXObject, no I/O.
var head = String.fromCharCode(91,73,78,69,82,84,93);            // "[INERT]"
var dom  = String.fromCharCode(109,97,108,105,99,105,111,117,115) // "malicious"
         + "." + "example" + String.fromCharCode(46) + "invalid";
var msg  = head + " js fromCharCode test | C2=" + dom + " | IP=198.51.100.42:4444";
WScript.Echo(msg);
